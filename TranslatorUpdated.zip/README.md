  We have no data sets, how to run the app is to go to this link: https://translator-ixyqcckissjuf57apt9kec.streamlit.app/
  The app has been deployed on to streamlit.
